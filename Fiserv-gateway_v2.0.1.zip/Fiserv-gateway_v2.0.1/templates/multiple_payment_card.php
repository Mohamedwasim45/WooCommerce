<?php if (!empty($installment_payment)) { ?>
    <div id="credit-card" class="Fiserv-credit-card">
        <p>
            <input id="_fullpaymet" type="radio" name="_fullpaymet" value="fullpayment" checked="checked"/> 
            <span><?php _e('Full Payment', 'woocommerce-Fiserv') ?></span>
        </p>

        <p>
            <input id="_installmentpaymet" type="radio" name="_fullpaymet" value="multiplepayment" /> 
            <span><?php _e('Instalment Payment', 'woocommerce-Fiserv') ?></span>
        <div id="installment_div" style="padding-left:40px;font-size: small;display:none;">
            <?php _e('Choose The Instalment', 'woocommerce-Fiserv'); ?>
            <div id="installment_itemdiv" style="padding-left:40px;padding-top:10px;line-height: 100%;">
                <?php
                foreach ($installment_payment as $Installment):
                    if (!empty($Installment['multipayment_description'])):
                        ?>
                        <p>
                            <input id="_multiplepayment" type="radio" name="_multiplepayment" value="<?php echo $Installment['multipayment_id']; ?>"/> 
                            <span><?php _e($Installment['multipayment_description']) ?></span>
                        </p>
                        <?php
                    endif;
                endforeach;
                ?>
            </div>
        </div>
    </p>
<?php } ?>
</div>

<script language='javascript'>
    jQuery('#_installmentpaymet').on( 'click', function(){
        jQuery('#installment_div').show(1000);				

    });
    jQuery('#_fullpaymet').on( 'click', function(){
        jQuery('#installment_div').hide(1000);				

    });
</script>


