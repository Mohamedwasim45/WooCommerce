<?php

/*
  Plugin Name: Fiserv - WooCommerce Gateway
  Plugin URI: http://www.Fiserv.com/
  Description: Extends WooCommerce by Adding the Fiserv payment Gateway.
  Version: 2.0
  Author: Fiserv,
  Author URI: http://www.Fiserv.com/

  Text Domain: woocommerce-Fiserv-gateway
  Domain Path: /languages/
 */
// Include our Gateway Class and register Payment Gateway with WooCommerce
add_action('plugins_loaded', 'Fiserv_gateway_init', 0);

function Fiserv_gateway_init() {
    // If the parent WC_Payment_Gateway class doesn't exist
    // it means WooCommerce is not installed on the site
    // so do nothing
    if (!class_exists('WC_Payment_Gateway'))
        return;

    // If we made it this far, then include our Gateway Class
    include_once( 'Fiserv.php' );

    // Now that we have successfully included our class,
    // Lets add it too WooCommerce
    add_filter('woocommerce_payment_gateways', 'spyr_add_Fiserv_gateway');

    function spyr_add_Fiserv_gateway($methods) {
        $methods[] = 'SPYR_Fiserv_Gateway';
        return $methods;
    }

    load_plugin_textdomain('woocommerce-Fiserv', false, dirname(plugin_basename(__FILE__)) . '/languages');
}

// Add custom action links
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'spyr_Fiserv_gateway_action_links');

function spyr_Fiserv_gateway_action_links($links) {
    $plugin_links = array(
        '<a href="' . admin_url('admin.php?page=wc-settings&tab=checkout&section=spyr_Fiserv_gateway') . '">' . __('Settings', 'spyr-Fiserv-gateway') . '</a>',
    );
    // Merge our new link with the default ones
    return array_merge($plugin_links, $links);
}